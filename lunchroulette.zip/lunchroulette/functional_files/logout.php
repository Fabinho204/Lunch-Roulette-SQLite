<?php
session_start();
session_destroy();
header("Location: ../visuals/login.php");
//head to -> login.php, sends HTTP header to the browser
